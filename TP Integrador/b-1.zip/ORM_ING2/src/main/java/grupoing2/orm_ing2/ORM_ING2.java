package grupoing2.orm_ing2;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class ORM_ING2 {

    public static void main(String[] args) {

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("zeroPU");
        
        System.out.println("JPA funciona correctamente");
        
        emf.close();
    }
}