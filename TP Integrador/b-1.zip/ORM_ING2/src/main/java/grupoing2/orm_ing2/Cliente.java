package grupoing2.orm_ing2;

import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import java.util.List;

@Entity
public class Cliente {
    
    @Id
    private Long id;
    
    private int dni;
    private String nombre;
    private String apelido;
    
    @OneToMany
    private List<Factura> facturas;
    
    @OneToOne
    private Domicilio domicilio;
}