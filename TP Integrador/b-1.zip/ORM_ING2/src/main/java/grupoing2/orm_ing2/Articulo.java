package grupoing2.orm_ing2;

import jakarta.persistence.Entity;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import java.util.List;

@Entity
public class Articulo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private int cantidad;
    private String denominacion;
    private int precio;
    
    @OneToMany
    private List<Categoria> categorias;
    
    @OneToMany
    private List<DetalleFactura> detallesFacturas;
}