package grupoing2.orm_ing2;

import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import java.util.List;

@Entity
public class Factura {
    
    @Id
    private Long id;
    
    private String fecha;
    private int numero;
    private int total;
    
    @OneToMany
    private List<DetalleFactura> detallesFacturas;
    
    @OneToOne
    private Cliente cliente;
}